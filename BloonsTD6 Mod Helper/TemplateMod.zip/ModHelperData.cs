﻿namespace TemplateMod;

public static class ModHelperData
{
    public const string Version = "1.0.0";
    public const string Name = "TemplateMod";

    public const string Description = "An empty mod";

    public const string RepoOwner = ""; // TODO add your github username hero
    public const string RepoName = ""; // TODO add your repo name here
}