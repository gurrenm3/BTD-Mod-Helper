﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkManagerCallbacksOrderOnTheHost_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "NetworkManagerCallbacksOrderOnTheHost_BridgeScriptGO";

    public GameObject playerPrefab;
}
