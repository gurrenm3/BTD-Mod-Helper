using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Stores")]
[assembly: InternalsVisibleTo("UnityEditor.Purchasing")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Stores")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.RuntimeTests")]
